document.addEventListener('DOMContentLoaded', () => {
    const contactBtn = document.getElementById('contactBtn');
    if (contactBtn) {
        contactBtn.addEventListener('click', () => {
            alert('Thank you for reaching out to CloudBridge Technologies! Our Cloud Engineering team will contact you shortly.');
        });
    }
});
